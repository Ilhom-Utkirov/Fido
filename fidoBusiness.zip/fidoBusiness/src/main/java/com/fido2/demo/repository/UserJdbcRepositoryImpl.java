package com.fido2.demo.repository;

import com.fido2.demo.entity.User;
import com.fido2.demo.mapper.UserMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public class UserJdbcRepositoryImpl implements UserJdbcRepository {

    public final JdbcTemplate jdbcTemplate;

    @Autowired
    public UserJdbcRepositoryImpl(JdbcTemplate jdbcTemplate) {
        this.jdbcTemplate = jdbcTemplate;
    }


    @Override
    public void save(User user) {
        String sql="INSERT INTO user(name, surname, email, credit ) VALUES (?, ?, ?, ?)";
        jdbcTemplate.update(sql,user.getName(),user.getSurname(),user.getEmail(),user.getCredit());
    }

    @Override
    public User findById(long id) {
        String sql = "SELECT*FROM user WHERE id=?";
        return jdbcTemplate.queryForObject(sql,new UserMapper(),id);
    }

    @Override
    public List<User> findAll() {
        String sql = "SELECT*FROM user";
        return jdbcTemplate.query(sql, new UserMapper());
    }

    @Override
    public void update(User user) {
        String sql = "UPDATE user SET name=?, surname=?, email =?, credit=? WHERE id= ?";
        jdbcTemplate.update(sql, user.getName(), user.getSurname(), user.getEmail(), user.getCredit(), user.getId());

    }


    @Override
    public void delete(long id) {
        String sql = "DELETE FROM user WHERE id=?";
        jdbcTemplate.update(sql,id);
    }
}
