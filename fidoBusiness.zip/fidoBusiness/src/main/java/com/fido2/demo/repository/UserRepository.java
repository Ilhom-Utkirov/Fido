package com.fido2.demo.repository;


import com.fido2.demo.entity.User;
import org.h2.store.Page;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import java.awt.print.Pageable;
import java.util.List;

@Repository
public interface UserRepository extends JpaRepository<User, Long> {


    //Page<User> findByIdOrderByName(long id, Pageable pageable);
               //findByProviderIOrderByIdStartCalculatingFromDesc (int id )
   // List<User> findByName(String name);
}
