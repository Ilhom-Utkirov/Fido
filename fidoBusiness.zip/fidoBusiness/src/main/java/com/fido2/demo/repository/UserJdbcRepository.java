package com.fido2.demo.repository;

import com.fido2.demo.entity.User;

import java.util.List;

public interface UserJdbcRepository {

    void save(User user);

    User findById(long id);

    List<User> findAll();

    void update(User user);

    void delete(long id);

}
