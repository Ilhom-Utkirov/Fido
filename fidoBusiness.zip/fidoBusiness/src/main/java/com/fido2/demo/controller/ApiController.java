package com.fido2.demo.controller;

import com.fido2.demo.entity.Goods;
import com.fido2.demo.entity.User;
import com.fido2.demo.repository.GoodsRepository;
import com.fido2.demo.repository.UserJdbcRepository;
import com.fido2.demo.repository.UserRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.*;

import javax.validation.Valid;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

@Controller
@RequestMapping
public class ApiController {
    @Autowired
    private final UserRepository userRepository;
    @Autowired
    private final GoodsRepository goodsRepository;
    @Autowired
    private final UserJdbcRepository userJdbcRepository;

    public ApiController(UserRepository userRepository, GoodsRepository goodsRepository, UserJdbcRepository userJdbcRepository) {
        this.userRepository = userRepository;
        this.goodsRepository = goodsRepository;
        this.userJdbcRepository = userJdbcRepository;
    }


    /*
    * ==================================
    *       working with jdbc          *
    *===================================
    * */


    @GetMapping("/userlistJdbc")
    public String showUserListJdbc(Model model){
        model.addAttribute("users",userJdbcRepository.findAll());
        return "user-list-jdbc";
    }

    @GetMapping("/signupJdbc")
    public String showSignUpFormJdbc(Model model) {
        model.addAttribute(new User());
        return "add-user-jdbc";
    }

    @PostMapping("/adduserJdbc")
    public String addUserJdbc(@Valid User user, BindingResult result, Model model) {
        if (result.hasErrors()) {
            return "add-user-jdbc";
        }

        userJdbcRepository.save(user);
        model.addAttribute("users", userJdbcRepository.findAll());
        return "user-list-jdbc";

    }

    @GetMapping("/editJdbc/{id}")
    public String showUpdateFormJdbc(@PathVariable("id") long id, Model model) {
        User user = userJdbcRepository.findById(id);
        model.addAttribute("user", user);
        return "update-user-jdbc";
    }

    @PostMapping("/updateJdbc/{id}")
    public String updateUserJdbc(@PathVariable("id") long id, @Valid User user, BindingResult result, Model model) {
        if (result.hasErrors()) {
            user.setId(id);
            return "update-user-jdbc";
        }
        userJdbcRepository.update(user);
        model.addAttribute("users", userJdbcRepository.findAll());
        return "redirect:/userlistJdbc";
    }

    @GetMapping("/deleteJdbc/{id}")
    public String deleteUserJdbc(@PathVariable("id") long id, Model model) {
        User user = userJdbcRepository.findById(id);
        userJdbcRepository.delete(id);
        model.addAttribute("users", userJdbcRepository.findAll());
        return "redirect:/userlistJdbc";
    }


/*
* ===========================
*       working on ajax     *
* ===========================
* */





    /*
    * ==============================
    * working with jpa              *
    * ==============================
    * */
    @GetMapping("/")
    public String showFirstPage(){
        return "index3";
    }



    @GetMapping("/userlist")
    public String showUserList(Model model){
        model.addAttribute("users",userJdbcRepository.findAll());
        return "user-list";
    }

    @GetMapping("/signup")
    public String showSignUpForm(Model model) {
        model.addAttribute(new User());
        return "add-user";
    }

    @PostMapping("/adduser")
    public String addUser(@Valid User user, BindingResult result, Model model) {
        if (result.hasErrors()) {
            return "add-user";
        }
        //user.setCredit(Integer.parseInt(String.valueOf(user.getCredit())));
        userRepository.save(user);
        model.addAttribute("users", userJdbcRepository.findAll());
        return "user-list";
        //return "redirect:/tables";
    }



    @GetMapping("/edit/{id}")
    public String showUpdateForm(@PathVariable("id") long id, Model model) {
        User user = userJdbcRepository.findById(id);
        model.addAttribute("user", user);
        return "update-user";
    }

    @PostMapping("/update/{id}")
    public String updateUser(@PathVariable("id") long id, @Valid User user, BindingResult result, Model model) {
        if (result.hasErrors()) {
            user.setId(id);
            return "update-user";
        }
        userJdbcRepository.update(user);
        model.addAttribute("users", userJdbcRepository.findAll());
        return "redirect:/userlist";
        //return "redirect:/tables";
    }

    @GetMapping("/delete/{id}")
    public String deleteUser(@PathVariable("id") long id, Model model) {
        User user = userJdbcRepository.findById(id);
        userJdbcRepository.delete(id);
        model.addAttribute("users", userJdbcRepository.findAll());
        return "redirect:/userlist";
        //return "redirect:/tables";
    }


    /*
    =========================
    *  //Maps for goods//
    =========================
    */

    //For paging purposes i used page request as it is deprecated
    //then i use method PageRequest.of from youtube comments
    @GetMapping("/index2")
    public String showGoodsPage(Model model, @RequestParam(defaultValue = "0") int page){
        model.addAttribute("data",goodsRepository.findAll( PageRequest.of(page,4)));
        model.addAttribute("currentPage", page);
        return "index2";
    }

    //needed get
    @PostMapping("/saveGoods")
    public String addGoods(Goods goods){
        goodsRepository.save(goods);
        return "redirect:/index2";
    }

    //needed get
    @GetMapping("/deleteGoods/{id}")
    public String deleteGoods(@PathVariable Long id, Model model){
        goodsRepository.deleteById(id);
        model.addAttribute("data",goodsRepository.findAll());

        return "redirect:/index2";
    }

    //needed get
    @GetMapping("/findOne/{id}")
    @ResponseBody
    public  Goods findOne(@PathVariable Long id){
        //Goods goods = goodsRepository.findById(id)
        return goodsRepository.findById(id).get();
    }


    /*
    * ===========================================
    *              maps for template users      *
    * ===========================================
    * */
    @GetMapping("/index")
    public String index(){
        return "index";
    }


    @GetMapping("/tables")
    public String tables(Model model ){
        model.addAttribute("users",userRepository.findAll());
        return "tables";
    }



    @RequestMapping("/ajax_list")
    @ResponseBody
    public HashMap<String, Object> showUserListAjax_List(
            //@RequestParam(value = "id", defaultValue = "0", required = false)long id,
            Pageable pageable
    ){
       /*
        Page<User> page;
        page = userRepository.findAll(pageable);

        HashMap<String, Object> result = new HashMap<>();

        result.put("recordsTotal", page.getTotalElements());//total elemets
        result.put("recordsFiltered", page.getTotalElements());//filtered elements
*/

       /* List<User> userAgreements = page.getContent();
          List<Object[]> convinientForJsonArray = new ArrayList<>(userAgreements.size());

        for(User agreement: userAgreements){

            convinientForJsonArray.add(new Object[]{
                    agreement.getId(),
                    agreement.getName(),
                    agreement.getSurname(),
                    agreement.getEmail(),
                    agreement.getCredit(),
            });
        }

        result.put("data",convinientForJsonArray);*/

        List<User> list;
        list=userRepository.findAll();
        HashMap<String, Object> result = new HashMap<>();

        List<Object[]> convinientForJsonArray = new ArrayList<>(list.size());
        for(User agreement: list){

            convinientForJsonArray.add(new Object[]{
                    agreement.getId(),
                    agreement.getName(),
                    agreement.getSurname(),
                    agreement.getEmail(),
                    agreement.getCredit(),
            });
        }

        result.put("data",convinientForJsonArray);
        return result;
    }



    @GetMapping("/signupUser")
    public String showSignUpFormUser(Model model) {
        model.addAttribute(new User());
        return "add-user-for-template";
    }

    //for table from template
    @PostMapping("/adduserTemplate")
    public String addUserTable(@Valid User user, BindingResult result, Model model) {
        if (result.hasErrors()) {
            return "add-user-for-template";
        }
        //user.setCredit(Integer.parseInt(String.valueOf(user.getCredit())));
        userRepository.save(user);
        model.addAttribute("users", userRepository.findAll());
        return "redirect:/tables";
    }


    @GetMapping("/editUser")
    public String showUpdateFormUser(
        //    @PathVariable("id") long id,
        @RequestParam(value = "id", defaultValue = "-1", required = false) long id,
            Model model) {
        User user = userRepository.findById(id).orElseThrow(() -> new IllegalArgumentException("Invalid user Id:" + id));
        // user.setCredit((double)user.getCredit());
        model.addAttribute("user", user);
        return "update-user-for-template";
    }

    @PostMapping("/updateUser")
    public String updateUserForm(
            //@PathVariable("id") long id,
            @RequestParam(value = "id", defaultValue = "-1", required = false) long id,
            @Valid User user, BindingResult result, Model model) {
        if (result.hasErrors()) {
            user.setId(id);
            return "update-user-for-template";
        }

        userRepository.save(user);
        model.addAttribute("users", userRepository.findAll());
        //return "redirect:/userlist";
        return "redirect:/tables";
    }

    @GetMapping("/deleteUser")
    public String deleteUserForm(
            //@PathVariable("id") long id,
            @RequestParam(value = "id", defaultValue = "-1", required = false) long id,
            Model model) {
        User user = userRepository.findById(id).orElseThrow(() -> new IllegalArgumentException("Invalid user Id:" + id));
        userRepository.delete(user);

        model.addAttribute("users", userRepository.findAll());
        return "redirect:/tables";
    }

    /*
     * ===========================================
     *              maps for template goods      *
     * ===========================================
     * */



    //For paging purposes i used page request as it is deprecated
    //then i use method PageRequest.of from youtube comments
    @GetMapping("/tableGoods")
    public String showGoodsPageTemplate(Model model, @RequestParam(defaultValue = "0") int page){
        model.addAttribute("data",goodsRepository.findAll( PageRequest.of(page,10)));
        model.addAttribute("currentPage", page);

        return "goods";
    }

    //needed get
    @PostMapping("/saveGoodsTemplate")
    public String addGoodsTemplate(Goods goods){
        goodsRepository.save(goods);
        return "redirect:/tableGoods";
    }

    //needed get
    @GetMapping("/deleteGoodsTemplate/{id}")
    public String deleteGoodsTemplate(@PathVariable("id")long id,
           // @RequestParam(value = "id", defaultValue = "-1", required = false) long id,
                                      Model model){
        //Goods goods = goodsRepository.findById(id).get();
        //goodsRepository.delete(goods);
        goodsRepository.deleteById(id);
        model.addAttribute("data",goodsRepository.findAll());
        return "redirect:/tableGoods";
    }

    @GetMapping("/findOneGood/{id}")
    @ResponseBody
    public  Goods findOneGood(//@RequestParam(value = "id", defaultValue = "-1", required = false) long id
                              @PathVariable("id")long id ){
        //Goods goods = goodsRepository.findById(id)
        return goodsRepository.findById(id).get();
    }

    @RequestMapping("/ajax_list_goods")
    @ResponseBody
    public HashMap<String, Object> showUserListAjax_ListGoods(
            Pageable pageable
    ){

        List<Goods> list;
        list=goodsRepository.findAll();
        HashMap<String, Object> result = new HashMap<>();

        List<Object[]> convinientForJsonArray = new ArrayList<>(list.size());
        for(Goods agreement: list){

            convinientForJsonArray.add(new Object[]{
                    agreement.getId(),
                    agreement.getGoodsName(),
                    agreement.getCost(),
            });
        }

        result.put("data",convinientForJsonArray);
        return result;
    }

    //I diidnot change findOne method as functional is the same



    /*
    * ======================
    * for charts           *
    * ======================
    * */

    @GetMapping("/charts")
    public String charts(){

        return "charts";
    }

}
